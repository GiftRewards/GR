<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
	
$B = array();

//Please edit database details

$B['DB_HOST'] = "_DB_HOST_";                                //localhost or your Database host
$B['DB_NAME'] = "_DB_NAME_";                             //your Database name
$B['DB_USER'] = "_DB_USER_";                             //your Database user
$B['DB_PASS'] = "_DB_PASSWORD_";                         //your Database password

// SMTP Settings | For password recovery

$B['SMTP_AUTH'] = true;                                     //SMTP auth (Enable SMTP authentication)
$B['SMTP_EMAIL'] = "example@gmail.com";                     //SMTP email
$B['SMTP_USERNAME'] = "example@gmail.com";                  //SMTP username
$B['SMTP_PASSWORD'] = "EMAIL_PASSWORD_HERE";                      //SMTP password

// TimeZone
// date_default_timezone_set('Asia/Kolkata');

$INSTALL_STATUS = "_INSTALL_STATUS_";

?>