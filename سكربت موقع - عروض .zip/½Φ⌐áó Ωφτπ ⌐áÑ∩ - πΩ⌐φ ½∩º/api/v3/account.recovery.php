<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
	 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
	 
require '../../admin/core/PHPMailer/Exception.php';
require '../../admin/core/PHPMailer/PHPMailer.php';
require '../../admin/core/PHPMailer/SMTP.php';

include_once("../api.inc.php");

if (!empty($_POST)) {

    $clientId = isset($_POST['clientId']) ? $_POST['clientId'] : 0;
    $email = isset($_POST['email']) ? $_POST['email'] : '';

    $clientId = helper::clearInt($clientId);
    $email = helper::escapeText($email);

    if ($clientId != CLIENT_ID) {

        api::printError(ERROR_UNKNOWN, "Error client Id.");
    }

    $result = array("error" => true, "error_code" => ERROR_UNKNOWN);

    if (helper::isCorrectEmail($email)) {

        $accountId = $helper->getUserIdByEmail($email);

        if ($accountId != 0) {

            $account = new account($dbo, $accountId);

            $accountInfo = $account->get();

            if ($accountInfo['error'] === false && $accountInfo['state'] != ACCOUNT_STATE_BLOCKED) {

                $restorePointInfo = $account->restorePointCreate($email, $clientId);
                
                $hash = $restorePointInfo['hash'];
                
                $configs = new functions($dbo);
                
                $APP_NAME = $configs->getConfig('APP_NAME');
                $appURL = $configs->getConfig('WEB_ROOT');
                        
                $message_html = '<html>
                        <body>
                            This is link <a href="'.$appURL.'admin/restore/?hash='.$hash.'">'.$appURL.'admin/restore/?hash='.$hash.'</a> to reset your password.
                        </body>
                    </html>';
                            
                $message_text = "This is link to reset your password : ".$appURL."admin/restore/?hash=".$hash;
                        
                $from = SMTP_EMAIL;
                        
                $to = $email;
        
                $subject = $APP_NAME." | Password reset";
        
                $mail = new PHPMailer(true);
                        
                try {
                            
                            //$mail->isSMTP();
                            $mail->Host       = 'smtp.gmail.com';
                            $mail->SMTPAuth   = SMTP_AUTH;
                            $mail->Username   = SMTP_USERNAME;
                            $mail->Password   = SMTP_PASSWORD;
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                            $mail->Port       = 587;
                        
                            //Recipient
                            $mail->setFrom($from, $APP_NAME);
                            $mail->addAddress($to);
                            $mail->addReplyTo($from, $APP_NAME);
                            $mail->addCC($from);
                            $mail->addBCC($from);
                        
                            // Content
                            $mail->isHTML(true);
                            $mail->Subject = $subject;
                            $mail->Body    = $message_html;
                            $mail->AltBody = $message_text;
                        
                            $mail->send();
                            
                    $result = array("error" => false,"error_code" => ERROR_SUCCESS);
                    
                } catch (Exception $e) {
                    
                    // Unable to send email
                    error_log("Error while sending Password Reset email. Error details : ".$mail->ErrorInfo);
                    
                    $result = array("error" => true,"error_code" => 400);
                } 
                
            }else{
                
                // user account either disabled or blocked
                $result = array("error" => true,"error_code" => 420);
            }
            
        }else{
            
            // No Account found with the provided email address
            $result = array("error" => true,"error_code" => 404);
        }
    }

    echo json_encode($result);
    exit;
}
