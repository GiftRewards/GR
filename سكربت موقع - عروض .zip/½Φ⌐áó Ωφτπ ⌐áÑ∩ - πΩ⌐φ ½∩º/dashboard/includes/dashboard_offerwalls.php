<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
?>
                                        <div class="kt-portlet kt-portlet--tabs">
                                            <div class="kt-portlet__head">
                                                <div class="kt-portlet__head-toolbar">
                                                    <ul class="nav nav-tabs nav-tabs-line nav-tabs-line-danger nav-tabs-line-2x nav-tabs-line-right" role="tablist">
                                                        
                                                        <?php if($configs->getConfig('AdMantumActive')){ ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link active" data-toggle="tab" href="#admantum" role="tab" aria-selected="true">
                                                                <i class="fa fa-dollar-sign" aria-hidden="true"></i>AdMantum
                                                            </a>
                                                        </li>
                                                        <?php } ?>
                                                        
                                                        <?php if($configs->getConfig('AdGateMediaActive')){ ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link" data-toggle="tab" href="#adgatemedia" role="tab" aria-selected="true">
                                                                <i class="fa fa-dollar-sign" aria-hidden="true"></i>AdGate Media
                                                            </a>
                                                        </li>
                                                        <?php } ?>
                                                        
                                                        <?php if($configs->getConfig('CpaLeadActive')){ ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link" data-toggle="tab" href="#cpalead" role="tab" aria-selected="true">
                                                                <i class="fa fa-dollar-sign" aria-hidden="true"></i>CpaLead
                                                            </a>
                                                        </li>
                                                        <?php } ?>
                                                        
                                                        <?php if($configs->getConfig('WannadsActive')){ ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link" data-toggle="tab" href="#wannads" role="tab" aria-selected="true">
                                                                <i class="fa fa-dollar-sign" aria-hidden="true"></i>Wannads
                                                            </a>
                                                        </li>
                                                        <?php } ?>
                                                        
                                                        <?php if($configs->getConfig('AdScendMediaActive')){ ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link" data-toggle="tab" href="#adscendmedia" role="tab" aria-selected="true">
                                                                <i class="fa fa-dollar-sign" aria-hidden="true"></i>Adscend Media
                                                            </a>
                                                        </li>
                                                        <?php } ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="kt-portlet__body">
                                                <div class="tab-content">
                                                    
                                                    <?php if($configs->getConfig('AdMantumActive')){ ?>
                                                    <div class="tab-pane active" id="admantum" role="tabpanel">
                                                        
                                                        <iframe src="https://www.admantum.com/offers?appid=<?php echo esc_attr($configs->getConfig('AdMantum_AppId')); ?>&uid=<?php echo esc_attr($req_user_info['login']); ?>" frameborder="0" width="100%" height="2400" ></iframe> 
                                                    
                                                    </div>
                                                    <?php } ?>
                                                    
                                                    <?php if($configs->getConfig('AdGateMediaActive')){ ?>
                                                    <div class="tab-pane" id="adgatemedia" role="tabpanel">
                                                        
                                                        <iframe src="http://wall.adgaterewards.com/<?php echo esc_attr($configs->getConfig('AdGate_Media_WallId')); ?>/<?php echo esc_attr($req_user_info['login']); ?>" frameborder="0" width="100%" height="2000" allowfullscreen></iframe>
                                                        
                                                    </div>
                                                    <?php } ?>
                                                    
                                                    <?php if($configs->getConfig('CpaLeadActive')){ ?>
                                                    <div class="tab-pane" id="cpalead" role="tabpanel">
                                                        
                                                        <iframe src="<?php echo esc_attr($configs->getConfig('CpaLead_DirectLink')); ?>&subid=<?php echo esc_attr($req_user_info['login']); ?>&subid2=<?php echo esc_attr($req_user_info['login']); ?>" frameborder="0" width="100%" height="2400" scrolling="yes"></iframe>
                                                        
			                                        </div>
                                                    <?php } ?>
                                                    
                                                    <?php if($configs->getConfig('WannadsActive')){ ?>
                                                    <div class="tab-pane" id="wannads" role="tabpanel">
                                                        
                                                        <iframe src="https://wall.wannads.com/wall?apiKey=<?php echo esc_attr($configs->getConfig('WannadsApiKey')); ?>&userId=<?php echo esc_attr($req_user_info['login']); ?>" frameborder="0" width="100%" height="2400" scrolling="yes"></iframe>
                                                        
			                                        </div>
                                                    <?php } ?>
                                                    
                                                    <?php if($configs->getConfig('AdScendMediaActive')){ ?>
                                                    <div class="tab-pane" id="adscendmedia" role="tabpanel">
                                                        
                                                        <iframe src="https://asmwall.com/adwall/publisher/<?php echo esc_attr($configs->getConfig('AdScendMedia_PubId')); ?>/profile/<?php echo esc_attr($configs->getConfig('AdScendMedia_AdwallId')); ?>?subid1=<?php echo esc_attr($req_user_info['login']); ?>" frameborder="0" width="100%" height="2000" allowfullscreen></iframe>
                                                    
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>