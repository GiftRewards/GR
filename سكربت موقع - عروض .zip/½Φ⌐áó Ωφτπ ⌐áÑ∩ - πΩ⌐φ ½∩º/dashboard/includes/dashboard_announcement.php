<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
?>
                                        <div class="kt-portlet kt-bg-brand kt-portlet--skin-solid">
                                        	<div class="kt-portlet__head ">
                                        		<div class="kt-portlet__head-label">
                                        			<h3 class="kt-portlet__head-title">Announcement</h3>
                                        		</div>
                                        	</div>
                                        	<div class="kt-portlet__body">
                                        		<!--begin::Widget 7-->
                                        		<div class="kt-widget7 kt-widget7--skin-light">
                                        			<div class="kt-widget7__desc mb-7">
                                        				<?php echo esc_attr($configs->getConfig('WEB_ANNOUNCEMENT_TEXT')); ?>
                                        			</div>
                                        		</div>
                                        		<!--end::Widget 7--> 
                                        	</div>
                                        </div>