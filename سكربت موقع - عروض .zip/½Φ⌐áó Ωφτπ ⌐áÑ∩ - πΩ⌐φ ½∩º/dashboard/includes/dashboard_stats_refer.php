<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
?>
                                        <div class="kt-portlet kt-iconbox kt-iconbox--animate">
                                        			<div class="kt-portlet__body">
                                        				<div class="kt-iconbox__body">
                                        					<div class="kt-iconbox__icon">
                                        						<i class="refer-stats-icon flaticon-users kt-font-brand"></i>
                                        					</div>
                                        					<div class="kt-iconbox__desc">
                                        						<h3 class="kt-iconbox__title">
                                        							<a class="kt-link"><?php echo esc_attr($userreferredMembers); ?></a>
                                        						</h3>
                                        						<div class="kt-iconbox__content">
                                        							Members Referred
                                        						</div>
                                        					</div>
                                        				</div>
                                        			</div>
                                        		</div>
                                        <div class="kt-portlet kt-iconbox kt-iconbox--animate">
                                        			<div class="kt-portlet__body">
                                        				<div class="kt-iconbox__body">
                                        					<div class="kt-iconbox__icon">
                                        						<i class="refer-stats-icon flaticon-coins kt-font-brand"></i>
                                                            </div>
                                        					<div class="kt-iconbox__desc">
                                        						<h3 class="kt-iconbox__title">
                                        							<a class="kt-link"><?php echo esc_attr($userIncomeFromReferredMembers); ?></a>
                                        						</h3>
                                        						<div class="kt-iconbox__content">
                                        							Referral Points Earned
                                        						</div>
                                        					</div>
                                        				</div>
                                        			</div>
                                        		</div>