<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */

?>
	    
	    <!-- Favicon -->
		<link rel="shortcut icon" href="<?php echo esc_attr($configs->getConfig('SITE_FAVICON')); ?>" />

		<meta charset="utf-8" />
		<title><?php echo esc_attr($APP_NAME); ?> | <?php echo esc_attr($APP_DESC); ?></title>
		<meta name="description" content="Pocket | Money Making Scripy by DroidOXY">