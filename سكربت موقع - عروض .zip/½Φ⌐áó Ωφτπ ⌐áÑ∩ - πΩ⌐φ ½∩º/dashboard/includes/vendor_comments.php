<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
?>
<!--
Template : Pocket - Money Making Script
Author: DroidOXY
Website: http://www.droidoxy.com/
Contact: support@droidoxy.com
Support: http://www.droidoxy.com/support

Purchase from Admin Panel [CodyHub]: https://www.codyhub.com/item/pocket-admin/?ref=droidoxy

Purchase from Web Version [CodyHub]: https://www.codyhub.com/item/web-rewards-app-pocket/?ref=droidoxy
Purchase from Android Version [CodyHub]: https://www.codyhub.com/item/android-rewards-app-pocket/?ref=droidoxy
Purchase from IOS Version [CodyHub]: https://www.codyhub.com/item/ios-rewards-app-pocket/?ref=droidoxy

Purchase from Web Version [Codecanyon]: https://codecanyon.net/item/web-rewards-app-pocket/25104366?ref=droidoxy
Purchase from Android Version [Codecanyon]: https://codecanyon.net/item/android-rewards-app-pocket/17413949?ref=droidoxy
Purchase from IOS Version [Codecanyon]: https://codecanyon.net/item/ios-rewards-app-pocket/24811671?ref=droidoxy

License: You must have a valid license purchased only from codyhub or codecanyon (the above links) in order to legally use this product.
-->
