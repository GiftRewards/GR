<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */
	 
	 use PHPMailer\PHPMailer\PHPMailer;
	 use PHPMailer\PHPMailer\Exception;
	 
	 require '../admin/core/PHPMailer/Exception.php';
	 require '../admin/core/PHPMailer/PHPMailer.php';
	 require '../admin/core/PHPMailer/SMTP.php';
	 
    include_once("../admin/core/init.inc.php");

    if (account::isSession()) {

        header("Location: index.php");
        exit;
    }
	
	$user_username = '';

    $error = false;
    $success = false;
    $error_message = '';
	$configs = new functions($dbo);
	
	$APP_NAME = $configs->getConfig('APP_NAME');
	$APP_DESC = $configs->getConfig('APP_DESC');
	
	$email = '';
	
	function esc_attr($attr){ return htmlspecialchars($attr, ENT_COMPAT, 'UTF-8'); }

    if (!empty($_POST)) {

        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $token = isset($_POST['authenticity_token']) ? $_POST['authenticity_token'] : '';

        $email = helper::clearText($email);

        $email = helper::escapeText($email);

        if (helper::getAuthenticityToken() !== $token) {

            $error = true;
            $error_message = 'Some Error, Try Again';
        }

        if (!$error) {

            if (helper::isCorrectEmail($email)) {
        
                $accountId = $helper->getUserIdByEmail($email);
        
                if ($accountId != 0) {
        
                    $account = new account($dbo, $accountId);
        
                    $accountInfo = $account->get();
        
                    if ($accountInfo['error'] === false && $accountInfo['state'] != ACCOUNT_STATE_BLOCKED) {
                        
                        $clientId = 0; // Web Version
        
                        $restorePointInfo = $account->restorePointCreate($email, $clientId);
                        
                        $hash = $restorePointInfo['hash'];
                        
                        $appURL = $configs->getConfig('WEB_ROOT');
                        
                        $message_html = '<html>
                                <body>
                                    This is link <a href="'.$appURL.'admin/restore/?hash='.$hash.'">'.$appURL.'admin/restore/?hash='.$hash.'</a> to reset your password.
                                </body>
                            </html>';
                            
                        $message_text = "This is link to reset your password : ".$appURL."admin/restore/?hash=".$hash;
                        
                        $from = SMTP_EMAIL;
                        
                        $to = $email;
        
                        $subject = $APP_NAME." | Password reset";
        
                        $mail = new PHPMailer(true);
                        
                        try {
                            
                            //$mail->isSMTP();
                            $mail->Host       = 'smtp.gmail.com';
                            $mail->SMTPAuth   = SMTP_AUTH;
                            $mail->Username   = SMTP_USERNAME;
                            $mail->Password   = SMTP_PASSWORD;
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                            $mail->Port       = 587;
                        
                            //Recipient
                            $mail->setFrom($from, $APP_NAME);
                            $mail->addAddress($to);
                            $mail->addReplyTo($from, $APP_NAME);
                            $mail->addCC($from);
                            $mail->addBCC($from);
                        
                            // Content
                            $mail->isHTML(true);
                            $mail->Subject = $subject;
                            $mail->Body    = $message_html;
                            $mail->AltBody = $message_text;
                        
                            $mail->send();
                            
                            $error = false;
                            $success = true;
                            $error_message = 'Password Reset Link has been sent to the email address. if you didn\'t find our email then please check your spam folder.';
                            
                        } catch (Exception $e) {
                            
                            //echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                            
                            $error = true;
                            $error_message = 'Error while sending Password Reset email. Error details : '.$mail->ErrorInfo;
                        }
                        
                    }else{
                            
                        $error = true;
                        $error_message = 'Account is either disbaled or Blocked.';
                    }
                    
                }else{
                    
                    $error = true;
                    $error_message = 'No Account is associated with the provided email address.';
                    
                }
                
            }else{
                
                $error = true;
                $error_message = 'Incorrect email address.';
                
            }
            
        }
    }

    helper::newAuthenticityToken();
    

?><!DOCTYPE html>
<?php include_once 'includes/vendor_comments.php'; ?>
<html lang="en">

	<!-- begin::Head -->
	<head>
	    <?php include_once 'includes/dashboard_title.php'; ?>
	    
	    <?php include_once 'includes/global_header_scripts.php'; ?>
	    
		<!--begin::Page Custom Styles(used by this page) -->
		<link href="assets/css/pages/login/login.css" rel="stylesheet" type="text/css" />
		<!--end::Page Custom Styles -->
		
	</head>
	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="kt-page--loading-enabled kt-page--loading kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header--minimize-menu kt-header-mobile--fixed kt-subheader--enabled kt-subheader--transparent kt-page--loading">

	    <?php include_once 'includes/dashboard_page_loader.php'; ?>

		<!-- begin:: Page -->
		<div class="kt-grid kt-grid--ver kt-grid--root kt-page">
			<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_login">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--desktop kt-grid--ver-desktop kt-grid--hor-tablet-and-mobile">

					<!--begin::Aside-->
					<div class="login-aside kt-grid__item kt-grid__item--order-tablet-and-mobile-2 kt-grid kt-grid--hor kt-login__aside">
						<div class="kt-grid__item">
							<a href="index.php" class="kt-login__logo">
								<img src="../admin/images/<?php echo esc_attr($configs->getConfig('SITE_LOGO_LIGHT')); ?>">
							</a>
						</div>
						<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver">
							<div class="kt-grid__item kt-grid__item--middle">
								<h3 class="kt-login__title">Welcome to <?php echo esc_attr($APP_NAME); ?>!</h3>
								<h4 class="kt-login__subtitle"><?php echo esc_attr($APP_DESC); ?></h4>
							</div>
						</div>
						<div class="kt-grid__item">
							<div class="kt-login__info">
								<div class="kt-login__copyright">
									&copy 2020 <?php echo esc_attr($APP_NAME); ?>
								</div>
							</div>
						</div>
					</div>

					<!--begin::Aside-->

					<!--begin::Content-->
					<div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">

						<!--begin::Body-->
						<div class="kt-login__body">

							<!--begin::Signin-->
							<div class="kt-login__form">
								<div class="kt-login__title">
									<h3>Reset Password</h3>
								</div>
								
								<?php if ($error){ ?>
								
    								<div class="alert alert-danger">
    								    <?php echo esc_attr($error_message); ?>
    								</div>
    								
								<?php } ?>
								
								<?php if ($success){ ?>
								
    								<div class="alert alert-success">
    								    <?php echo esc_attr($error_message); ?>
    								</div>
    								
								<?php }else{ ?>

								<!--begin::Form-->
								<form class="kt-form" action="forgot-password.php" method="post" novalidate="novalidate" id="needs-validation kt_login_form">
								    <input autocomplete="off" type="hidden" name="authenticity_token" value="<?php echo helper::getAuthenticityToken(); ?>">
									<div class="form-group">
										<input class="form-control" placeholder="Enter your email address" id="email" name="email" type="email" value="<?php echo esc_attr($email); ?>" required>
									</div>

									<!--begin::Action-->
									<div class="kt-login__actions">
										<span class="kt-link kt-login__link-forgot">
											&nbsp;
										</span>
										<button type="submit" id="kt_login_signin_submit" class="btn btn-primary btn-elevate kt-login__btn-primary">Reset Password</button>
									</div>

									<!--end::Action-->
								</form>

								<!--end::Form-->
								
								<?php } ?>

								<!--begin::Divider-->
								<div class="form-bootom-text">
								    <span class="kt-login__signup-label">Have an account ?</span>&nbsp;&nbsp;
								    <a href="login.php" class="kt-link kt-login__signup-link">Login Here</a>
								</div>

								<!--end::Divider-->
							</div>

							<!--end::Signin-->
						</div>

						<!--end::Body-->
					</div>

					<!--end::Content-->
				</div>
			</div>
		</div>
		<!-- end:: Page -->
		
	    <?php include_once 'includes/global_footer_scripts.php'; ?>

		<!--begin::Page Vendors(used by this page) -->

		<!--end::Page Vendors -->

		<!--begin::Page Scripts(used by this page) -->
		<script src="assets/js/pages/custom/login/login.js" type="text/javascript"></script>

		<!--end::Page Scripts -->
	</body>

	<!-- end::Body -->
</html>