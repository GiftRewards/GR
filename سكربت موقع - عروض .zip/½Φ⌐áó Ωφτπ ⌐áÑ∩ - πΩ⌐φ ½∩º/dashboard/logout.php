<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */

	include_once("../admin/core/init.inc.php");

    if (!account::isSession()) {

        header('Location: ../../');
        exit;
    }

    if (isset($_GET['access_token'])) {

        $accessToken = (isset($_GET['access_token'])) ? ($_GET['access_token']) : '';

        if (account::getAccessToken() === $accessToken) {

            account::unsetSession();

            header('Location: ../../');
            exit;
        }
    }

    header('Location: ../../');